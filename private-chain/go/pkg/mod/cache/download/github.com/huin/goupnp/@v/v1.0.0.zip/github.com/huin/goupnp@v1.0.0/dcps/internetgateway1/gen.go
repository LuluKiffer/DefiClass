//go:generate goupnpdcpgen -dcp_name internetgateway1
package internetgateway1
